var soma = 0;
for(var i=2;i<process_params.argv.lenght-1;i++)
   soma=soma+Number(provess.argv[i]);
   console.log("soma="+soma);