const fs = require('fs');
const data = fs.readFileSync('file.txt');
//a execução é bloquada aqui ate o arquivo ser lido
console.log(data.toString());